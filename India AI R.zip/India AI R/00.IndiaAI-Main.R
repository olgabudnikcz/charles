library (abind)
library (geomorph)
library (viridis)
library(ggplot2)


# ==== CUSTOM FUNCTIONS ====

## CALCULATING GROUP-RELEVANT SHAPESCORES

giveGroupVec <- function(coord,groupvar,iter = 9999){
  
  dframe <- geomorph.data.frame(coords = coord, group = groupvar)
  reg1 <- procD.lm(coords ~ group, iter = iter, data = dframe)
  
  print(summary(reg1))
  
  coefficients<-coef(reg1, test = F)
  
  scores <- two.d.array (coord) %*% t(coefficients)
  sc <- scores [,2]
  
  groupvar <- as.numeric(as.factor(groupvar))
  
  g1sc <- subset (sc, groupvar == 1)
  g2sc <- subset (sc, groupvar == 2)
  
  gcoef<-t(coefficients)[,2]
  
  return(list(sc=sc, g1sc=g1sc, g2sc=g2sc, gcoef=gcoef))
}



## ==== LOADING SHAPE DATA ====

slids <- read.table ("slidersR.txt")
links <- read.table ("linksR.txt")

## AI Czech Data

wczflux <- readland.tps ("AI_CZECH/CZ-FLUX-WOMEN.tps")
mczflux <- readland.tps ("AI_CZECH/CZ-FLUX-MEN.tps")

wczgem <- readland.tps ("AI_CZECH/CZ-GEM-WOMEN.tps")
mczgem <- readland.tps ("AI_CZECH/CZ-GEM-MEN.tps")

wczmidj <- readland.tps ("AI_CZECH/CZ-MIDJ-WOMEN.tps")
mczmidj <- readland.tps ("AI_CZECH/CZ-MIDJ-MEN.tps")

wczsd <- readland.tps ("AI_CZECH/CZ-SD-WOMEN.tps")
mczsd <- readland.tps ("AI_CZECH/CZ-SD-MEN.tps")

wczgpt <- readland.tps ("AI_CZECH/CZ-GPT-WOMEN.tps")
mczgpt <- readland.tps ("AI_CZECH/CZ-GPT-MEN.tps")

wczgrok <- readland.tps ("AI_CZECH/CZ-GROK-WOMEN.tps")
mczgrok <- readland.tps ("AI_CZECH/CZ-GROK-MEN.tps")

## AI India Data

windflux <- readland.tps ("AI_INDIA/IND-FLUX-WOMEN.tps")
mindflux <- readland.tps ("AI_INDIA/IND-FLUX-MEN.tps")

windgem <- readland.tps ("AI_INDIA/IND-GEM-WOMEN.tps")
mindgem <- readland.tps ("AI_INDIA/IND-GEM-MEN.tps")

windmidj <- readland.tps ("AI_INDIA/IND-MIDJ-WOMEN.tps")
mindmidj <- readland.tps ("AI_INDIA/IND-MIDJ-MEN.tps")

windsd <- readland.tps ("AI_INDIA/IND-SD-WOMEN.tps")
mindsd <- readland.tps ("AI_INDIA/IND-SD-MEN.tps")

windgpt <- readland.tps ("AI_INDIA/IND-GPT-WOMEN.tps")
mindgpt <- readland.tps ("AI_INDIA/IND-GPT-MEN.tps")

windgrok <- readland.tps ("AI_INDIA/IND-GROK-WOMEN.tps")
mindgrok <- readland.tps ("AI_INDIA/IND-GROK-MEN.tps")

## Real Czech Data 

wcz_1 <- readland.tps ("Real_CZECH/F_CZ_ZUZBUSS.TPS")
wcz_2 <- readland.tps ("Real_CZECH/F_CZ12-13_enf.TPS")
wcz_3 <- readland.tps ("Real_CZECH/F_cz16.tps")
wcz_4 <- readland.tps ("Real_CZECH/F_cz120.tps")

mcz_1 <- readland.tps ("Real_CZECH/M_CZ_ZUZBUSS.TPS")
mcz_2 <- readland.tps ("Real_CZECH/M_CZ12-13_enf.TPS")
mcz_3 <- readland.tps ("Real_CZECH/M_cz16.tps")
mcz_4 <- readland.tps ("Real_CZECH/M_cz120.tps")

## Real India Data

wind_1 <- readland.tps ("Real_INDIA/W_women_enface_I_Nalagarh.TPS")
wind_2 <- readland.tps ("Real_INDIA/W_GAD_zeny_enf.tps")
wind_3 <- readland.tps ("Real_INDIA/W_KON_zeny_enf.tps")
wind_4 <- readland.tps ("Real_INDIA/W_Ahiri_Women_Enf.tps")

mind_1 <- readland.tps ("Real_INDIA/M_Rabari_Men_Enf.tps")
mind_2 <- readland.tps ("Real_INDIA/M_men_enface_I_Nalagarh.tps")
mind_3 <- readland.tps ("Real_INDIA/M_KON_muzi_enf.tps")
mind_4 <- readland.tps ("Real_INDIA/M_GAD_muzi_enf.tps")
mind_5 <- readland.tps ("Real_INDIA/M_Arihi_Men_Enf.tps")



## ==== ORGANIZING SHAPE DATASETS ====

windai <- abind(windflux, windgem, windmidj, windsd, windgpt, windgrok)
mindai <- abind(mindflux, mindgem, mindmidj, mindsd, mindgpt, mindgrok)
indai <- abind (windai, mindai)

indflux <- abind (windflux, mindflux)
indgem <- abind (windgem, mindgem)
indmidj <- abind (windmidj, mindmidj)
indsd <- abind (windsd, mindsd)
indgpt <- abind (windgpt, mindgpt)
indgrok <- abind (windgrok, mindgrok)

wczai <- abind(wczflux, wczgem, wczmidj, wczsd, wczgpt, wczgrok)
mczai <- abind(mczflux, mczgem, mczmidj, mczsd, mczgpt, mczgrok)
czai <- abind (wczai, mczai)

czflux <- abind (wczflux, mczflux)
czgem <- abind (wczgem, mczgem)
czmidj <- abind (wczmidj, mczmidj)
czsd <- abind (wczsd, mczsd)
czgpt <- abind (wczgpt, mczgpt)
czgrok <- abind (wczgrok, mczgrok)

wai <- abind (windai, wczai)
mai <- abind (mindai, mczai)
ai <- abind (wai, mai)
dim(ai)

windreal <- abind (wind_1, wind_2, wind_3, wind_4)
mindreal <- abind (mind_1, mind_2, mind_3, mind_4, mind_5)
indreal <- abind (windreal, mindreal)

wczreal <- abind (wcz_1, wcz_2, wcz_3, wcz_4)
mczreal <- abind (mcz_1, mcz_2, mcz_3, mcz_4)
czreal <- abind (wczreal, mczreal)

wreal <- abind (windreal, wczreal)
mreal <- abind (mindreal, mczreal)
real <- abind (wreal, mreal)
dim(real)

w <- abind (wreal, wai)
m <- abind (mreal, mai)
indall <- abind(indreal, indai)
czall <- abind(czreal, czai)

all <- abind (real, ai)
dim(all)



## ==== PERFORMING GENERALIZED PROCRUSTES ANALYSIS ====

gpall <- gpagen(all,  ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
plot(gpall)

gp_ai <- gpagen(ai,  ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
plot(gp_ai) 

gp_real <- gpagen(real,  ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
plot(gp_real) 

## GPA for India

indgpall <- gpagen(indall,  ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
gp_indflux <- gpagen(indflux, ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
gp_indgem <- gpagen(indgem, ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
gp_indmidj <- gpagen(indmidj, ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
gp_indsd <- gpagen(indsd, ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
gp_indgpt <- gpagen(indgpt, ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
gp_indgrok <- gpagen(indgrok, ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
gp_indreal <- gpagen(indreal, ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)

## GPA for CZ

czgpall <- gpagen(czall,  ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
gp_czflux <- gpagen(czflux, ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
gp_czgem <- gpagen(czgem, ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
gp_czmidj <- gpagen(czmidj, ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
gp_czsd <- gpagen(czsd, ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
gp_czgpt <- gpagen(czgpt, ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
gp_czgrok <- gpagen(czgrok, ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
gp_czreal <- gpagen(czreal, ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)



## ==== CREATING FACTOR VARIABLES ====

groups <- factor(c(rep("real", dim(real)[3]), rep("ai", dim(ai)[3])))
summary(groups)

## Indian Face Groups

indgroups <- factor(c(rep("indreal", dim(indreal)[3]),
                      rep("indai", dim(indai)[3])))

indface.groups <- factor(c(rep("indreal", dim(indreal)[3]),
                           rep("indflux", dim(windflux)[3]),
                           rep("indgem", dim(windgem)[3]),
                           rep("indmidj", dim(windmidj)[3]),
                           rep("indsd", dim(windsd)[3]),
                           rep("indgpt", dim(windgpt)[3]),
                           rep("indgrok", dim(windgrok)[3]),
                           rep("indflux", dim(mindflux)[3]),
                           rep("indgem", dim(mindgem)[3]),
                           rep("indmidj", dim(mindmidj)[3]),
                           rep("indsd", dim(mindsd)[3]),
                           rep("indgpt", dim(mindgpt)[3]),
                           rep("indgrok", dim(mindgrok)[3])))
summary(indface.groups)

indflux.groups <- factor(c(rep("indreal", dim(indreal)[3]), rep("indflux", dim(indflux)[3])))
indgem.groups <- factor(c(rep("indreal", dim(indreal)[3]), rep("indgem", dim(indgem)[3])))
indmidj.groups <- factor(c(rep("indreal", dim(indreal)[3]), rep("indmidj", dim(indmidj)[3])))
indsd.groups <- factor(c(rep("indreal", dim(indreal)[3]), rep("indsd", dim(indsd)[3])))
indgpt.groups <- factor(c(rep("indreal", dim(indreal)[3]), rep("indgpt", dim(indgpt)[3])))
indgrok.groups <- factor(c(rep("indreal", dim(indreal)[3]), rep("indgrok", dim(indgrok)[3])))

indflux.sshd.groups <- factor(c(rep("windflux", dim(windflux)[3]), rep("mindflux", dim(mindflux)[3])))
indgem.sshd.groups <- factor(c(rep("windgem", dim(windgem)[3]), rep("mindgem", dim(mindgem)[3])))
indmidj.sshd.groups <- factor(c(rep("windmidj", dim(windmidj)[3]), rep("mindmidj", dim(mindmidj)[3])))
indsd.sshd.groups <- factor(c(rep("windsd", dim(windsd)[3]), rep("mindsd", dim(mindsd)[3])))
indgpt.sshd.groups <- factor(c(rep("windgpt", dim(windgpt)[3]), rep("mindgpt", dim(mindgpt)[3])))
indgrok.sshd.groups <- factor(c(rep("windgrok", dim(windgrok)[3]), rep("mindgrok", dim(mindgrok)[3])))
indreal.sshd.groups <- factor(c(rep("windreal", dim(windreal)[3]), rep("mindreal", dim(mindreal)[3])))

## Czech Face Groups

czgroups <- factor(c(rep("czreal", dim(czreal)[3]),
                     rep("czai", dim(czai)[3])))

czface.groups <- factor(c(rep("czreal", dim(czreal)[3]),
                          rep("czflux", dim(wczflux)[3]),
                          rep("czgem", dim(wczgem)[3]),
                          rep("czmidj", dim(wczmidj)[3]),
                          rep("czsd", dim(wczsd)[3]),
                          rep("czgpt", dim(wczgpt)[3]),
                          rep("czgrok", dim(wczgrok)[3]),
                          rep("czflux", dim(mczflux)[3]),
                          rep("czgem", dim(mczgem)[3]),
                          rep("czmidj", dim(mczmidj)[3]),
                          rep("czsd", dim(mczsd)[3]),
                          rep("czgpt", dim(mczgpt)[3]),
                          rep("czgrok", dim(mczgrok)[3])))
summary(czface.groups)

czflux.groups <- factor(c(rep("czreal", dim(czreal)[3]), rep("czflux", dim(czflux)[3])))
czgem.groups <- factor(c(rep("czreal", dim(czreal)[3]), rep("czgem", dim(czgem)[3])))
czmidj.groups <- factor(c(rep("czreal", dim(czreal)[3]), rep("czmidj", dim(czmidj)[3])))
czsd.groups <- factor(c(rep("czreal", dim(czreal)[3]), rep("czsd", dim(czsd)[3])))
czgpt.groups <- factor(c(rep("czreal", dim(czreal)[3]), rep("czgpt", dim(czgpt)[3])))
czgrok.groups <- factor(c(rep("czreal", dim(czreal)[3]), rep("czgrok", dim(czgrok)[3])))

czflux.sshd.groups <- factor(c(rep("wczflux", dim(wczflux)[3]), rep("mczflux", dim(mczflux)[3])))
czgem.sshd.groups <- factor(c(rep("wczgem", dim(wczgem)[3]), rep("mczgem", dim(mczgem)[3])))
czmidj.sshd.groups <- factor(c(rep("wczmidj", dim(wczmidj)[3]), rep("mczmidj", dim(mczmidj)[3])))
czsd.sshd.groups <- factor(c(rep("wczsd", dim(wczsd)[3]), rep("mczsd", dim(mczsd)[3])))
czgpt.sshd.groups <- factor(c(rep("wczgpt", dim(wczgpt)[3]), rep("mczgpt", dim(mczgpt)[3])))
czgrok.sshd.groups <- factor(c(rep("wczgrok", dim(wczgrok)[3]), rep("mczgrok", dim(mczgrok)[3])))
czreal.sshd.groups <- factor(c(rep("wczreal", dim(wczreal)[3]), rep("mczreal", dim(mczreal)[3])))




## ==== INDIVIDUAL SQUARED PROCRUSTES DISTANCES ====

individual.disparity <- function(coords, groups) {
  groups <- factor(groups)
  stopifnot(length(groups) == dim(coords)[3], !anyNA(groups))
  distances <- numeric(dim(coords)[3])
  for (g in levels(groups)) {
    idx <- which(groups == g)
    mean.shape <- apply(coords[, , idx, drop = FALSE], c(1, 2), mean)
    distances[idx] <- vapply(idx, function(i) sum((coords[, , i] - mean.shape)^2), numeric(1))
  }
  data.frame(group = groups, squared.distance = distances)
}


## ==== INDIVIDUAL PROCRUSTES DISTANCES ALL AI VS REAL FACES ====

## Indian Women

indw <- abind(windreal, windai)
gp_indw <- gpagen(indw, ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
indw.groups <- factor(c(rep("real", dim(windreal)[3]),
                        rep("ai", dim(windai)[3])))
df_indw <- individual.disparity(gp_indw$coords, indw.groups)

ggplot(df_indw, aes(x = group, y = squared.distance, fill = group)) +
  scale_y_continuous(labels = function(x) format(x, scientific = FALSE)) +
  geom_hline(yintercept = 0, colour = "grey80", linetype = "dashed") +
  geom_boxplot(width = 0.7, colour = "grey30", linewidth = 0.3, alpha = 0.9, fatten = 0) +
  stat_summary(fun = mean, fun.min = mean, fun.max = mean, geom = "crossbar", width = 0.7, colour = "grey30", linewidth = 0.3) +
  scale_fill_manual(values = c("real" = "lightblue", "ai" = "salmon"), guide = "none") +
  scale_x_discrete(labels = c("ai" = "AI", "real" = "Real")) +
  labs(x = "", y = "Squared individual Procrustes distance from the group mean shape", title = "Indian Women: AI vs Real Faces") +
  theme_classic(base_size = 12) +
  theme(
    plot.margin = margin(30, 30, 30, 30),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 11),
    axis.text.y = element_text(angle = 90, hjust = 1, size = 9),
    plot.title = element_text(hjust = 0.5, size = 15, margin = margin(b = 15)),
    axis.line.x = element_line(color = "grey30", linewidth = 0.3),
    axis.line.y = element_line(color = "grey30", linewidth = 0.3)
  )


## Indian Men

indm <- abind(mindreal, mindai)
gp_indm <- gpagen(indm, ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
indm.groups <- factor(c(rep("real", dim(mindreal)[3]),
                        rep("ai", dim(mindai)[3])))
df_indm <- individual.disparity(gp_indm$coords, indm.groups)

ggplot(df_indm, aes(x = group, y = squared.distance, fill = group)) +
  scale_y_continuous(labels = function(x) format(x, scientific = FALSE)) +
  geom_hline(yintercept = 0, colour = "grey80", linetype = "dashed") +
  geom_boxplot(width = 0.7, colour = "grey30", linewidth = 0.3, alpha = 0.9, fatten = 0) +
  stat_summary(fun = mean, fun.min = mean, fun.max = mean, geom = "crossbar", width = 0.7, colour = "grey30", linewidth = 0.3) +
  scale_fill_manual(values = c("real" = "lightblue", "ai" = "salmon"), guide = "none") +
  scale_x_discrete(labels = c("ai" = "AI", "real" = "Real")) +
  labs(x = "", y = "Squared individual Procrustes distance from the group mean shape", title = "Indian Men: AI vs Real Faces") +
  theme_classic(base_size = 12) +
  theme(
    plot.margin = margin(30, 30, 30, 30),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 11),
    axis.text.y = element_text(angle = 90, hjust = 1, size = 9),
    plot.title = element_text(hjust = 0.5, size = 15, margin = margin(b = 15)),
    axis.line.x = element_line(color = "grey30", linewidth = 0.3),
    axis.line.y = element_line(color = "grey30", linewidth = 0.3)
  )


## Czech Women

czw <- abind(wczreal, wczai)
gp_czw <- gpagen(czw, ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
czw.groups <- factor(c(rep("real", dim(wczreal)[3]),
                       rep("ai", dim(wczai)[3])))
df_czw <- individual.disparity(gp_czw$coords, czw.groups)

ggplot(df_czw, aes(x = group, y = squared.distance, fill = group)) +
  scale_y_continuous(labels = function(x) format(x, scientific = FALSE)) +
  geom_hline(yintercept = 0, colour = "grey80", linetype = "dashed") +
  geom_boxplot(width = 0.7, colour = "grey30", linewidth = 0.3, alpha = 0.9, fatten = 0) +
  stat_summary(fun = mean, fun.min = mean, fun.max = mean, geom = "crossbar", width = 0.7, colour = "grey30", linewidth = 0.3) +
  scale_fill_manual(values = c("real" = "lightblue", "ai" = "salmon"), guide = "none") +
  scale_x_discrete(labels = c("ai" = "AI", "real" = "Real")) +
  labs(x = "", y = "Squared individual Procrustes distance from the group mean shape", title = "Czech Women: AI vs Real Faces") +
  theme_classic(base_size = 12) +
  theme(
    plot.margin = margin(30, 30, 30, 30),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 11),
    axis.text.y = element_text(angle = 90, hjust = 1, size = 9),
    plot.title = element_text(hjust = 0.5, size = 15, margin = margin(b = 15)),
    axis.line.x = element_line(color = "grey30", linewidth = 0.3),
    axis.line.y = element_line(color = "grey30", linewidth = 0.3)
  )


## Czech Men

czm <- abind(mczreal, mczai)
gp_czm <- gpagen(czm, ProcD = F, curves = slids, PrinAxes = F, Proj = TRUE)
czm.groups <- factor(c(rep("real", dim(mczreal)[3]),
                       rep("ai", dim(mczai)[3])))
df_czm <- individual.disparity(gp_czm$coords, czm.groups)

ggplot(df_czm, aes(x = group, y = squared.distance, fill = group)) +
  scale_y_continuous(labels = function(x) format(x, scientific = FALSE)) +
  geom_hline(yintercept = 0, colour = "grey80", linetype = "dashed") +
  geom_boxplot(width = 0.7, colour = "grey30", linewidth = 0.3, alpha = 0.9, fatten = 0) +
  stat_summary(fun = mean, fun.min = mean, fun.max = mean, geom = "crossbar", width = 0.7, colour = "grey30", linewidth = 0.3) +
  scale_fill_manual(values = c("real" = "lightblue", "ai" = "salmon"), guide = "none") +
  scale_x_discrete(labels = c("ai" = "AI", "real" = "Real")) +
  labs(x = "", y = "Squared individual Procrustes distance from the group mean shape", title = "Czech Men: AI vs Real Faces") +
  theme_classic(base_size = 12) +
  theme(
    plot.margin = margin(30, 30, 30, 30),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 11),
    axis.text.y = element_text(angle = 90, hjust = 1, size = 9),
    plot.title = element_text(hjust = 0.5, size = 15, margin = margin(b = 15)),
    axis.line.x = element_line(color = "grey30", linewidth = 0.3),
    axis.line.y = element_line(color = "grey30", linewidth = 0.3)
  )


## ==== INDIVIDUAL PROCRUSTES DISTANCES SEPARATE AI MODELS VS REAL FACES ====

## Indian

df_indgroups <- individual.disparity(indgpall$coords, indface.groups)
df_indgroups$group <- factor(df_indgroups$group,
                             levels = c("indflux", "indgem", "indgpt", "indgrok", "indmidj", "indsd", "indreal"))

bg_df <- data.frame(xmin = 0.5:6.5, xmax = 1.5:7.5,
                    ymin = -Inf, ymax = Inf, fill_bg = rep(c("grey97", "white"), length.out = 7))

ggplot(df_indgroups, aes(x = group, y = squared.distance, fill = group)) +
  scale_y_continuous(labels = function(x) format(x, scientific = FALSE)) +
  geom_rect(data = bg_df, inherit.aes = FALSE, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
            fill = bg_df$fill_bg, alpha = 0.9) +
  geom_hline(yintercept = 0, colour = "grey80", linetype = "dashed") +
  geom_boxplot(width = 0.7, colour = "grey30", linewidth = 0.3, alpha = 0.9, fatten = 0) +
  stat_summary(fun = mean, fun.min = mean, fun.max = mean, geom = "crossbar", width = 0.7, colour = "grey30", linewidth = 0.3) +
  scale_fill_manual(values = c("#8DD3C7", "#FDB462", "#80B1D3", "#B3DE69", "#FB8072", "#CCEBC5", "#BC80BD"), guide = "none") +
  scale_x_discrete(labels = c("FLUX", "Gemini", "GPT", "Grok", "MidJour", "StDiff", "Real")) +
  labs(x = "", y = "Squared individual Procrustes distance from the group mean shape", title = "Individual Procrustes Distances for India (AI vs Real Faces)") +
  theme_classic(base_size = 12) +
  theme(
    plot.margin = margin(30, 30, 30, 30),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 11),
    axis.text.y = element_text(angle = 90, hjust = 1, size = 9),
    plot.title = element_text(hjust = 0.5, size = 15, margin = margin(b = 15)),
    axis.line.x = element_line(color = "grey30", linewidth = 0.3),
    axis.line.y = element_line(color = "grey30", linewidth = 0.3))


## Czech

df_czgroups <- individual.disparity(czgpall$coords, czface.groups)
df_czgroups$group <- factor(df_czgroups$group,
                            levels = c("czflux", "czgem", "czgpt", "czgrok", "czmidj", "czsd", "czreal"))

bg_df <- data.frame(xmin = 0.5:6.5, xmax = 1.5:7.5,
                    ymin = -Inf, ymax = Inf, fill_bg = rep(c("grey97", "white"), length.out = 7))

ggplot(df_czgroups, aes(x = group, y = squared.distance, fill = group)) +
  scale_y_continuous(labels = function(x) format(x, scientific = FALSE)) +
  geom_rect(data = bg_df, inherit.aes = FALSE, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
            fill = bg_df$fill_bg, alpha = 0.9) +
  geom_hline(yintercept = 0, colour = "grey80", linetype = "dashed") +
  geom_boxplot(width = 0.7, colour = "grey30", linewidth = 0.3, alpha = 0.9, fatten = 0) +
  stat_summary(fun = mean, fun.min = mean, fun.max = mean, geom = "crossbar", width = 0.7, colour = "grey30", linewidth = 0.3) +
  scale_fill_manual(values = c("#8DD3C7", "#FDB462", "#80B1D3", "#B3DE69", "#FB8072", "#CCEBC5", "#BC80BD"), guide = "none") +
  scale_x_discrete(labels = c("FLUX", "Gemini", "GPT", "Grok", "MidJour", "StDiff", "Real")) +
  labs(x = "", y = "Squared individual Procrustes distance from the group mean shape", title = "Individual Procrustes Distances for Czechia (AI vs Real Faces)") +
  theme_classic(base_size = 12) +
  theme(
    plot.margin = margin(30, 30, 30, 30),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 11),
    axis.text.y = element_text(angle = 90, hjust = 1, size = 9),
    plot.title = element_text(hjust = 0.5, size = 15, margin = margin(b = 15)),
    axis.line.x = element_line(color = "grey30", linewidth = 0.3),
    axis.line.y = element_line(color = "grey30", linewidth = 0.3))


## ==== TESTING MORPHOLOGICAL DISPARITY ====

morphol.disparity(two.d.array(gpall$coords) ~ groups, groups = groups,
                  iter = 9999, seed = NULL, data = NULL, print.progress = TRUE) ## all AI vs Real

morphol.disparity(two.d.array(indgpall$coords) ~ indgroups, groups = indgroups,
                  iter = 9999, seed = NULL, data = NULL, print.progress = TRUE) ## Indian AI vs Real

morphol.disparity(two.d.array(indgpall$coords) ~ indface.groups, groups = indface.groups,
                  iter = 9999, seed = NULL, data = NULL, print.progress = TRUE) ## Indian AI vs Real + 6 AI

morphol.disparity(two.d.array(czgpall$coords) ~ czgroups, groups = czgroups,
                  iter = 9999, seed = NULL, data = NULL, print.progress = TRUE) ## CZ AI vs Real

morphol.disparity(two.d.array(czgpall$coords) ~ czface.groups, groups = czface.groups,
                  iter = 9999, seed = NULL, data = NULL, print.progress = TRUE) ## CZ AI vs Real + 6 AI


## Indian Women & separate AI models

indwface.groups <- factor(c(rep("indreal", dim(windreal)[3]),
                            rep("indflux", dim(windflux)[3]),
                            rep("indgem", dim(windgem)[3]),
                            rep("indmidj", dim(windmidj)[3]),
                            rep("indsd", dim(windsd)[3]),
                            rep("indgpt", dim(windgpt)[3]),
                            rep("indgrok", dim(windgrok)[3])))

morphol.disparity(two.d.array(gp_indw$coords) ~ indwface.groups, groups = indwface.groups,
                  iter = 9999, seed = NULL, data = NULL, print.progress = TRUE)


## Indian Men & separate AI models

indmface.groups <- factor(c(rep("indreal", dim(mindreal)[3]),
                            rep("indflux", dim(mindflux)[3]),
                            rep("indgem", dim(mindgem)[3]),
                            rep("indmidj", dim(mindmidj)[3]),
                            rep("indsd", dim(mindsd)[3]),
                            rep("indgpt", dim(mindgpt)[3]),
                            rep("indgrok", dim(mindgrok)[3])))

morphol.disparity(two.d.array(gp_indm$coords) ~ indmface.groups, groups = indmface.groups,
                  iter = 9999, seed = NULL, data = NULL, print.progress = TRUE)


## Czech Women & separate AI models

czwface.groups <- factor(c(rep("czreal", dim(wczreal)[3]),
                           rep("czflux", dim(wczflux)[3]),
                           rep("czgem", dim(wczgem)[3]),
                           rep("czmidj", dim(wczmidj)[3]),
                           rep("czsd", dim(wczsd)[3]),
                           rep("czgpt", dim(wczgpt)[3]),
                           rep("czgrok", dim(wczgrok)[3])))

morphol.disparity(two.d.array(gp_czw$coords) ~ czwface.groups, groups = czwface.groups,
                  iter = 9999, seed = NULL, data = NULL, print.progress = TRUE)


## Czech Men & separate AI models

czmface.groups <- factor(c(rep("czreal", dim(mczreal)[3]),
                           rep("czflux", dim(mczflux)[3]),
                           rep("czgem", dim(mczgem)[3]),
                           rep("czmidj", dim(mczmidj)[3]),
                           rep("czsd", dim(mczsd)[3]),
                           rep("czgpt", dim(mczgpt)[3]),
                           rep("czgrok", dim(mczgrok)[3])))

morphol.disparity(two.d.array(gp_czm$coords) ~ czmface.groups, groups = czmface.groups,
                  iter = 9999, seed = NULL, data = NULL, print.progress = TRUE)


## ==== TESTING DIFFERENCE BETWEEN GROUP MEANS ====

## India

indgtest <- procD.lm(indgpall$coords ~ indgroups, iter = 9999)
summary(indgtest)

indface.group <- coords.subset(indgpall$coords, indface.groups)

indallgtest <- procD.lm(indgpall$coords ~ indface.groups, iter = 9999)
summary(indallgtest)

indfluxreal.test <- procD.lm(abind(indface.group$indreal, indface.group$indflux) ~ indflux.groups, iter = 9999)
summary(indfluxreal.test)

indgemreal.test <- procD.lm(abind(indface.group$indreal, indface.group$indgem) ~ indgem.groups, iter = 9999)
summary(indgemreal.test)

indmidjreal.test <- procD.lm(abind(indface.group$indreal, indface.group$indmidj) ~ indmidj.groups, iter = 9999)
summary(indmidjreal.test)

indsdreal.test <- procD.lm(abind(indface.group$indreal, indface.group$indsd) ~ indsd.groups, iter = 9999)
summary(indsdreal.test)

indgptreal.test <- procD.lm(abind(indface.group$indreal, indface.group$indgpt) ~ indgpt.groups, iter = 9999)
summary(indgptreal.test)

indgrokreal.test <- procD.lm(abind(indface.group$indreal, indface.group$indgrok) ~ indgrok.groups, iter = 9999)
summary(indgrokreal.test)


## CZ

czgtest <- procD.lm(czgpall$coords ~ czgroups, iter = 9999)
summary(czgtest)

czface.group <- coords.subset(czgpall$coords, czface.groups)

czallgtest <- procD.lm(czgpall$coords ~ czface.groups, iter = 9999)
summary(czallgtest)

czfluxreal.test <- procD.lm(abind(czface.group$czreal, czface.group$czflux) ~ czflux.groups, iter = 9999)
summary(czfluxreal.test)

czgemreal.test <- procD.lm(abind(czface.group$czreal, czface.group$czgem) ~ czgem.groups, iter = 9999)
summary(czgemreal.test)

czmidjreal.test <- procD.lm(abind(czface.group$czreal, czface.group$czmidj) ~ czmidj.groups, iter = 9999)
summary(czmidjreal.test)

czsdreal.test <- procD.lm(abind(czface.group$czreal, czface.group$czsd) ~ czsd.groups, iter = 9999)
summary(czsdreal.test)

czgptreal.test <- procD.lm(abind(czface.group$czreal, czface.group$czgpt) ~ czgpt.groups, iter = 9999)
summary(czgptreal.test)

czgrokreal.test <- procD.lm(abind(czface.group$czreal, czface.group$czgrok) ~ czgrok.groups, iter = 9999)
summary(czgrokreal.test)





## ==== TESTING SEXUAL FACIAL SHAPE DIMORPHISM - AI MODELS VS REAL FACES ====

## India SSHD

indflux.sshd <- giveGroupVec(gp_indflux$coords, indflux.sshd.groups)
indgem.sshd <- giveGroupVec(gp_indgem$coords, indgem.sshd.groups)
indmidj.sshd <- giveGroupVec(gp_indmidj$coords, indmidj.sshd.groups)
indsd.sshd <- giveGroupVec(gp_indsd$coords, indsd.sshd.groups)
indgpt.sshd <- giveGroupVec(gp_indgpt$coords, indgpt.sshd.groups)
indgrok.sshd <- giveGroupVec(gp_indgrok$coords, indgrok.sshd.groups)
indreal.sshd <- giveGroupVec(gp_indreal$coords, indreal.sshd.groups)

inddf_sshd <- data.frame(
  model = c(rep("indflux", length(indflux.sshd$sc)), rep("indgem", length(indgem.sshd$sc)),
            rep("indmidj",  length(indmidj.sshd$sc)), rep("indsd", length(indsd.sshd$sc)), 
            rep("indgpt", length(indgpt.sshd$sc)), rep("indgrok",   length(indgrok.sshd$sc)), rep("indreal", length(indreal.sshd$sc))),
  sex = c(as.character(indflux.sshd.groups), as.character(indgem.sshd.groups), as.character(indmidj.sshd.groups),
          as.character(indsd.sshd.groups), as.character(indgpt.sshd.groups), as.character(indgrok.sshd.groups), as.character(indreal.sshd.groups)),
  score = c(indflux.sshd$sc, indgem.sshd$sc, indmidj.sshd$sc, indsd.sshd$sc, indgpt.sshd$sc, indgrok.sshd$sc, indreal.sshd$sc))

inddf_sshd$sex <- ifelse(grepl("^w", inddf_sshd$sex), "Women", "Men")
inddf_sshd$sex <- factor(inddf_sshd$sex, levels = c("Men", "Women"))
inddf_sshd$model <- factor(inddf_sshd$model,
                           levels = c("indflux","indgem","indgpt","indgrok","indmidj","indsd","indreal"))

bg_df <- data.frame(xmin = seq_len(nlevels(inddf_sshd$model)) - 0.5, xmax = seq_len(nlevels(inddf_sshd$model)) + 0.5,
                    ymin = -Inf, ymax =  Inf, fill_bg = rep(c("grey97", "white"), length.out = nlevels(inddf_sshd$model)))
ggplot(inddf_sshd, aes(x = model, y = score, fill = sex)) +
  scale_y_continuous(labels = function(x) format(x, scientific = FALSE)) +
  geom_rect(data = bg_df, inherit.aes = FALSE, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
            fill = bg_df$fill_bg, alpha = 0.9) +
  geom_hline(yintercept = 0, colour = "grey80", linetype = "dashed") +
  geom_boxplot(width = 1, position = position_dodge(width = 0), colour = "grey30", linewidth = 0.3, alpha = 0.9) +
  scale_fill_manual(values = c("Men"   = "lightblue", "Women" = "salmon"), name = "") +
  scale_x_discrete(labels = c("indflux" = "FLUX", "indgem" = "Gemini", "indgpt" = "GPT", "indgrok" = "Grok",
                              "indmidj" = "MidJour", "indsd" = "StDiff", "indreal" = "Real")) +
  labs(x = "", y = "", title = "Sexual Facial Shape Dimorphism for India") +
  theme_classic(base_size = 12) +
  theme(
    plot.margin = margin(30, 30, 30, 30),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 11),
    axis.text.y = element_text(angle = 90, hjust = 1, size = 9),
    plot.title  = element_text(hjust = 0.5, size = 15, margin = margin(b = 15)),
    axis.line.x = element_line(color = "grey30", linewidth = 0.3),
    axis.line.y = element_line(color = "grey30", linewidth = 0.3))


## Czech SSHD

czflux.sshd <- giveGroupVec(gp_czflux$coords, czflux.sshd.groups)
czgem.sshd <- giveGroupVec(gp_czgem$coords, czgem.sshd.groups)
czmidj.sshd <- giveGroupVec(gp_czmidj$coords, czmidj.sshd.groups)
czsd.sshd <- giveGroupVec(gp_czsd$coords, czsd.sshd.groups)
czgpt.sshd <- giveGroupVec(gp_czgpt$coords, czgpt.sshd.groups)
czgrok.sshd <- giveGroupVec(gp_czgrok$coords, czgrok.sshd.groups)
czreal.sshd <- giveGroupVec(gp_czreal$coords, czreal.sshd.groups)

czdf_sshd <- data.frame(
  model = c(rep("czflux", length(czflux.sshd$sc)), rep("czgem", length(czgem.sshd$sc)),
            rep("czmidj",  length(czmidj.sshd$sc)), rep("czsd", length(czsd.sshd$sc)), 
            rep("czgpt", length(czgpt.sshd$sc)), rep("czgrok",   length(czgrok.sshd$sc)), rep("czreal", length(czreal.sshd$sc))),
  sex = c(as.character(czflux.sshd.groups), as.character(czgem.sshd.groups), as.character(czmidj.sshd.groups),
          as.character(czsd.sshd.groups), as.character(czgpt.sshd.groups), as.character(czgrok.sshd.groups), as.character(czreal.sshd.groups)),
  score = c(czflux.sshd$sc, czgem.sshd$sc, czmidj.sshd$sc, czsd.sshd$sc, czgpt.sshd$sc, czgrok.sshd$sc, czreal.sshd$sc))

czdf_sshd$sex <- ifelse(grepl("^w", czdf_sshd$sex), "Women", "Men")
czdf_sshd$sex <- factor(czdf_sshd$sex, levels = c("Men", "Women"))
czdf_sshd$model <- factor(czdf_sshd$model,
                          levels = c("czflux","czgem","czgpt","czgrok","czmidj","czsd","czreal"))

bg_df <- data.frame(xmin = seq_len(nlevels(czdf_sshd$model)) - 0.5, xmax = seq_len(nlevels(czdf_sshd$model)) + 0.5,
                    ymin = -Inf, ymax =  Inf, fill_bg = rep(c("grey97", "white"), length.out = nlevels(czdf_sshd$model)))
ggplot(czdf_sshd, aes(x = model, y = score, fill = sex)) +
  scale_y_continuous(labels = function(x) format(x, scientific = FALSE)) +
  geom_rect(data = bg_df, inherit.aes = FALSE, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
            fill = bg_df$fill_bg, alpha = 0.9) +
  geom_hline(yintercept = 0, colour = "grey80", linetype = "dashed") +
  geom_boxplot(width = 1, position = position_dodge(width = 0), colour = "grey30", linewidth = 0.3, alpha = 0.9) +
  scale_fill_manual(values = c("Men"   = "lightblue", "Women" = "salmon"), name = "") +
  scale_x_discrete(labels = c("czflux" = "FLUX", "czgem" = "Gemini", "czgpt" = "GPT", "czgrok" = "Grok",
                              "czmidj" = "MidJour", "czsd" = "StDiff", "czreal" = "Real")) +
  labs(x = "", y = "", title = "Sexual Facial Shape Dimorphism for Czechia") +
  theme_classic(base_size = 12) +
  theme(
    plot.margin = margin(30, 30, 30, 30),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 11),
    axis.text.y = element_text(angle = 90, hjust = 1, size = 9),
    plot.title  = element_text(hjust = 0.5, size = 15, margin = margin(b = 15)),
    axis.line.x = element_line(color = "grey30", linewidth = 0.3),
    axis.line.y = element_line(color = "grey30", linewidth = 0.3))




## ==== TESTING THE LEVEL OF FLUCTUATING ASYMMETRY FOR AI VS REAL FACES ====

## All

left  <- c(50,51,52,53,54,55,56,57,58, 5,7,12,10,70,15,17,18,20,26,23,21,22,21,25,24,71, 35,46,45,44,34,49,48,47)
right <- c(59,60,61,62,63,64,65,66,67, 4,6,11,9,69,14,16,19,27,33,29,28,30,28,32,31,72, 37,38,39,40,36,41,42,43)
land.pairs <- cbind(left, right)

coords_all <- gpall$coords
ind_all <- factor(seq_len(dim(coords_all)[3]))

fa_res <- bilat.symmetry(A = coords_all, ind = ind_all, land.pairs = land.pairs, object.sym = TRUE, iter = 9999)
fa_all <- fa_res$unsigned.AI

face.groups <- factor(c(as.character(indface.groups)[seq_len(dim(indreal)[3])],
                        as.character(czface.groups)[seq_len(dim(czreal)[3])],
                        as.character(indface.groups)[-seq_len(dim(indreal)[3])][seq_len(dim(windai)[3])],
                        as.character(czface.groups)[-seq_len(dim(czreal)[3])][seq_len(dim(wczai)[3])],
                        as.character(indface.groups)[-seq_len(dim(indreal)[3])][dim(windai)[3] + seq_len(dim(mindai)[3])],
                        as.character(czface.groups)[-seq_len(dim(czreal)[3])][dim(wczai)[3] + seq_len(dim(mczai)[3])]))

df_fa <- data.frame(group = groups, face.groups = face.groups, FA = fa_all)

fa_anova <- procD.lm(FA ~ group, data = df_fa, iter = 9999)
summary(fa_anova)

fa_models <- procD.lm(FA ~ face.groups, data = df_fa, iter = 9999)
summary(fa_models)


## Women and Men Separately

## India

indcoords_all <- indgpall$coords
ind_all <- factor(seq_len(dim(indcoords_all)[3]))

indfa_res <- bilat.symmetry(A = indcoords_all, ind = ind_all, land.pairs = land.pairs, object.sym = TRUE, iter = 9999)
indfa_all <- indfa_res$unsigned.AI

n_windreal <- dim(windreal)[3]
n_mindreal <- dim(mindreal)[3]
n_windai <- dim(windai)[3]
n_mindai <- dim(mindai)[3]

indsex_all <- c(rep("Women", n_windreal), rep("Men", n_mindreal),
                rep("Women", n_windai), rep("Men", n_mindai))
indsex_all <- factor(indsex_all, levels = c("Women","Men"))

inddf_fa2 <- data.frame(group = indgroups, face.groups = indface.groups, sex = indsex_all, FA = indfa_all)

inddf_women <- inddf_fa2[inddf_fa2$sex == "Women", ]
inddf_men <- inddf_fa2[inddf_fa2$sex == "Men", ]

indfa_anova_w <- procD.lm(FA ~ group, data = inddf_women, iter = 9999)
summary(indfa_anova_w)

indfa_models_w <- procD.lm(FA ~ face.groups, data = inddf_women, iter = 9999)
summary(indfa_models_w)

indfa_anova_m <- procD.lm(FA ~ group, data = inddf_men, iter = 9999)
summary(indfa_anova_m)

indfa_models_m <- procD.lm(FA ~ face.groups, data = inddf_men, iter = 9999)
summary(indfa_models_m)


## CZ

czcoords_all <- czgpall$coords
cz_all <- factor(seq_len(dim(czcoords_all)[3]))

czfa_res <- bilat.symmetry(A = czcoords_all, ind = cz_all, land.pairs = land.pairs, object.sym = TRUE, iter = 9999)
czfa_all <- czfa_res$unsigned.AI

n_wczreal <- dim(wczreal)[3]
n_mczreal <- dim(mczreal)[3]
n_wczai <- dim(wczai)[3]
n_mczai <- dim(mczai)[3]

czsex_all <- c(rep("Women", n_wczreal), rep("Men", n_mczreal),
               rep("Women", n_wczai), rep("Men", n_mczai))
czsex_all <- factor(czsex_all, levels = c("Women","Men"))

czdf_fa2 <- data.frame(group = czgroups, face.groups = czface.groups, sex = czsex_all, FA = czfa_all)

czdf_women <- czdf_fa2[czdf_fa2$sex == "Women", ]
czdf_men <- czdf_fa2[czdf_fa2$sex == "Men", ]

czfa_anova_w <- procD.lm(FA ~ group, data = czdf_women, iter = 9999)
summary(czfa_anova_w)

czfa_models_w <- procD.lm(FA ~ face.groups, data = czdf_women, iter = 9999)
summary(czfa_models_w)

czfa_anova_m <- procD.lm(FA ~ group, data = czdf_men, iter = 9999)
summary(czfa_anova_m)

czfa_models_m <- procD.lm(FA ~ face.groups, data = czdf_men, iter = 9999)
summary(czfa_models_m)

## ==== FA: EACH AI MODEL VS REAL ====

library(geomorph)

compare_fa <- function(d, pop) {
  g <- unique(as.character(d$face.groups))
  real <- grep("real", g, ignore.case = TRUE, value = TRUE)
  
  do.call(rbind, lapply(setdiff(g, real), function(m) {
    x <- droplevels(subset(d, face.groups %in% c(real, m)))
    a <- summary(procD.lm(FA ~ face.groups, data = x, iter = 9999))$table
    data.frame(Population = pop, Model = m,
               F = a[1, "F"], R2 = a[1, "Rsq"],
               p = a[1, "Pr(>F)"],
               df1 = a[1, "Df"], df2 = a[2, "Df"])
  }))
}

fa_table <- rbind(
  compare_fa(inddf_fa2, "India"),
  compare_fa(czdf_fa2, "Czechia")
)

print(fa_table, row.names = FALSE)

summary(procD.lm(FA ~ group, data = inddf_fa2, iter = 9999))
summary(procD.lm(FA ~ group, data = czdf_fa2, iter = 9999))